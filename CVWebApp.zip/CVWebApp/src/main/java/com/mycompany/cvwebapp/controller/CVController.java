package com.mycompany.cvwebapp.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import model.CV;
import java.io.File;

@WebServlet("/CVController")
@MultipartConfig
public class CVController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // get form data
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String education = request.getParameter("education");
        String experience = request.getParameter("experience");
        String skills = request.getParameter("skills");
        String position = request.getParameter("position");
        String address = request.getParameter("address");
        String linkedin = request.getParameter("linkedin");
        String profileSummary = request.getParameter("profileSummary");
        String languages = request.getParameter("languages");

        Part filePart = request.getPart("photo");
        String fileName = filePart.getSubmittedFileName();

        // save file
        String uploadPath = getServletContext().getRealPath("/images");

        // create folder
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        
        // store in model
        CV cv = new CV();
        
        // write file
           if (fileName != null && !fileName.isEmpty()) {
    filePart.write(uploadPath + "/" + fileName);
    cv.setPhoto("images/" + fileName);
    System.out.println(uploadPath);
} else {
    cv.setPhoto("images/default.jpg");
}

        cv.setName(name);
        cv.setPosition(position);
        cv.setPhone(phone);
        cv.setAddress(address);
        cv.setEmail(email);
        cv.setLinkedin(linkedin);
        cv.setProfileSummary(profileSummary);
        cv.setExperience(experience);
        cv.setEducation(education);
        cv.setLanguages(languages);
        cv.setSkills(skills);
        

        // send to view
        request.setAttribute("cv", cv);

        RequestDispatcher rd = request.getRequestDispatcher("views/cv.jsp");
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("example".equals(action)) {

            // HARDCODED DATA
            CV cv = new CV();
            cv.setPhoto("images/default.jpg");
            cv.setName("Nur Adelia");
            cv.setPosition("Data Analyst");
            cv.setPhone("011-39067898");
            cv.setAddress("Kemaman, Terengganu");
            cv.setEmail("adeliaa@email.com");
            cv.setLinkedin("www.adelia.com");
            cv.setProfileSummary("Highly analytical Data Analyst with a strong foundation in statistical modeling and complex problem-solving. "
                               + "Proficient in transforming raw datasets into actionable insights through rigorous mathematical analysis and technical precision."
                               + "A proactive communicator dedicated to driving data-informed decisions and optimizing organizational processes.");
            cv.setExperience(   "Intern at Shopee Malaysia (2024)\nAssisted with sales reporting\nWorked with customer analytics.");
            cv.setEducation("Bachelor in Information Technology (2022)\nUiTM Shah Alam");
            cv.setLanguages("English: Professional\nMalay: Native \nArabic: Conversational");
            cv.setSkills("Java, HTML, CSS, MySQL");
            

            request.setAttribute("cv", cv);

            RequestDispatcher rd = request.getRequestDispatcher("views/cv.jsp");
            rd.forward(request, response);

        } else {
            response.sendRedirect("views/form.jsp");
        }
    }
}