<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>CV Form</title>
</head>

<body class="bg-gray-100 flex justify-center items-center min-h-screen">

<div class="bg-white shadow-lg rounded-2xl p-8 w-full max-w-2xl">
    
    <h1 class="text-2xl font-bold mb-2">CV Generator</h1>
    <p class="text-gray-500 mb-6">Enter your information to generate your CV</p>

    <form action="../CVController" method="post" enctype="multipart/form-data">

        <!-- Picture -->
        <div class="mb-4">
            <label class="block mb-1">Picture</label>
            <input class="border rounded w-full p-2" type="file" name="photo">
        </div>

        <!-- Name & Position -->
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block mb-1">Name</label>
                <input class="border rounded w-full p-2" type="text" name="name" placeholder="e.g. Nur Adelia">
            </div>
            <div>
                <label class="block mb-1">Position</label>
                <input class="border rounded w-full p-2" type="text" name="position" placeholder="e.g. Data Analyst">
            </div>
        </div>

        <!-- Phone & Address -->
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block mb-1">Phone Number</label>
                <input class="border rounded w-full p-2" type="text" name="phone" placeholder="e.g. 011-39067898">
            </div>
            <div>
                <label class="block mb-1">Address</label>
                <input class="border rounded w-full p-2" type="text" name="address" placeholder="e.g. Kemaman, Terengganu">
            </div>
        </div>

        <!-- Email & Website -->
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block mb-1">Email</label>
                <input class="border rounded w-full p-2" type="text" name="email" placeholder="e.g. adelia@email.com">
            </div>
            <div>
                <label class="block mb-1">Website</label>
                <input class="border rounded w-full p-2" type="text" name="linkedin" placeholder="e.g. https://www.linkedin.com/in/yourname">
            </div>
        </div>

        <!-- Textareas -->
        <div class="mb-4">
            <label class="block mb-1">Profile Summary</label>
            <textarea class="border rounded w-full p-2" name="profileSummary" placeholder="Write a brief professional summary about yourself..."></textarea>
        </div>

        <div class="mb-4">
            <label class="block mb-1">Work Experience</label>
            <textarea class="border rounded w-full p-2" name="experience" placeholder="Please write in this format: 

Intern at Shopee Malaysia (2024)
Assisted with sales reporting
Worked with customer analytics"></textarea>
        </div>

        <div class="mb-4">
            <label class="block mb-1">Education</label>
            <textarea class="border rounded w-full p-2" name="education" placeholder="Please write in this format:
                      
Bachelor in Information Technology (2022)
UiTM Shah Alam"></textarea>
        </div>

        <div class="mb-4">
            <label class="block mb-1">Language Skills</label>
            <textarea class="border rounded w-full p-2" name="languages" placeholder="English
Malay
Arabic"></textarea>
        </div>

        <div class="mb-4">
            <label class="block mb-1">Skills</label>
            <textarea class="border rounded w-full p-2" name="skills" placeholder="Java, HTML, CSS, MySQL"></textarea>
        </div>

        <!-- Buttons -->
        <div class="flex gap-4 mt-6">
            <button class="bg-gray-300 hover:bg-gray-400 text-black font-semibold px-4 py-2 rounded">
                Generate CV
            </button>

            <button type="button"
        onclick="window.location.href='${pageContext.request.contextPath}/CVController?action=example'"
        class="bg-gray-300 hover:bg-gray-400 text-black font-semibold px-4 py-2 rounded">
          View Example CV
         </button>
        </div>

    </form>
</div>

</body>
</html>