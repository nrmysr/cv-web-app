<%@ page import="model.CV" %>
<%
    CV cv = (CV) request.getAttribute("cv");

    if (cv == null) {
        out.println("CV not found");
        return;
    }
%>


<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>My CV</title>
</head>

<body class="bg-gray-200 flex justify-center p-10">

<div class="bg-white shadow-lg rounded-xl w-full max-w-4xl grid grid-cols-3">

    <!-- LEFT SIDE -->
    <div class="bg-gray-100 p-6 text-center">

         <!-- PHOTO -->
        <img src="<%= request.getContextPath() + "/" + cv.getPhoto() %>" 
             class="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-white shadow">

        <!-- CONTACT -->
        <h2 class="font-bold mt-4 mb-2 text-gray-700">Contact</h2>
        <p class="text-sm text-gray-600"><%= cv.getAddress() %></p>
        <p class="text-sm text-gray-600"><%= cv.getPhone() %></p>
        <p class="text-sm text-gray-600"><%= cv.getEmail() %></p>
        <p>
            <a href="<%= cv.getLinkedin() %>" class="text-blue-500 text-sm">
                Website
            </a>
        </p>

        <!-- SKILLS -->
        <h2 class="font-bold mt-6 mb-2 text-gray-700">Skills</h2>
        <ul class="text-sm text-gray-600 text-left list-disc ml-6">
        <%
            if (cv.getSkills() != null) {
                 String[] skillsArray = cv.getSkills().split("[,\\n]");
            for (String skill : skillsArray) {
                if (!skill.trim().isEmpty()) {
        %>
             <li><%= skill.trim() %></li>
        <%
                     }
                }
            }
        %>
</ul>

        <!-- LANGUAGES -->
        <h2 class="font-bold mt-6 mb-2 text-gray-700">Languages</h2>
        <ul class="text-sm text-gray-600 text-left list-disc ml-6">
        <%
            if (cv.getLanguages() != null) {
                String[] langArray = cv.getLanguages().split("[,\\n]");
            for (String lang : langArray) {
            if (!lang.trim().isEmpty()) {
        %>
            <li><%= lang.trim() %></li>
        <%
                    }
                }
            }
        %>
        </ul>

    </div>

    <!-- RIGHT SIDE -->
    <div class="col-span-2 p-6">

        <!-- NAME + POSITION -->
        <h1 class="text-3xl font-bold text-gray-800">
            <%= cv.getName() %>
        </h1>
        <p class="text-gray-500 mb-4"><%= cv.getPosition() %></p>

        <!-- PROFILE -->
        <h2 class="mt-6 font-semibold border-b pb-1 text-gray-700">Profile</h2>
        <p class="text-gray-600 mt-2"><%= cv.getProfileSummary() %></p>

<!-- EXPERIENCE -->
<h2 class="mt-6 font-semibold border-b pb-1 text-gray-700">Experience</h2>
<div class="text-gray-600 mt-2 space-y-3">
<%
if (cv.getExperience() != null) {

    String[] lines = cv.getExperience().split("\\n");

    for (int i = 0; i < lines.length; i++) {

        String line = lines[i].trim();
        if (line.isEmpty()) continue;

        // detect new job (line with year)
        boolean isNewJob =
            line.matches(".*\\(\\d{4}\\).*") || line.matches(".*\\d{4}.*");

        if (isNewJob) {
%>
    <ul class="list-disc ml-6">
        <!-- MAIN (circle bullet) -->
        <li>
            <%= line %>

            <!-- SUB DETAILS -->
            <ul class="ml-4 mt-1">
<%
            i++;
            while (i < lines.length) {
                String next = lines[i].trim();

                // stop when next job starts
                if (next.matches(".*\\(\\d{4}\\).*") || next.matches(".*\\d{4}.*")) {
                    i--;
                    break;
                }

                if (!next.isEmpty()) {
%>
                <li>- <%= next %></li>
<%
                }
                i++;
            }
%>
            </ul>
        </li>
    </ul>
<%
        }
    }
}
%>
</div>

<!-- EDUCATION -->
<h2 class="mt-6 font-semibold border-b pb-1 text-gray-700">Education</h2>
<div class="text-gray-600 mt-2 space-y-3">
<%
if (cv.getEducation() != null) {

    String[] lines = cv.getEducation().split("\\n");

    for (int i = 0; i < lines.length; i++) {

        String line = lines[i].trim();
        if (line.isEmpty()) continue;

        // detect new education (line with year)
        boolean isNewEducation =
            line.matches(".*\\(\\d{4}\\).*") || line.matches(".*\\d{4}.*");

        if (isNewEducation) {
%>
    <ul class="list-disc ml-6">
        <!-- MAIN (circle bullet) -->
        <li>
            <%= line %>

            <!-- SUB DETAILS -->
            <ul class="ml-4 mt-1">
<%
            i++;
            while (i < lines.length) {
                String next = lines[i].trim();

                // stop when next education starts
                if (next.matches(".*\\(\\d{4}\\).*") || next.matches(".*\\d{4}.*")) {
                    i--;
                    break;
                }

                if (!next.isEmpty()) {
%>
                <li>- <%= next %></li>
<%
                }
                i++;
            }
%>
            </ul>
        </li>
    </ul>
<%
        }
    }
}
%>
</div>
</div>

</body>
</html>